//
//  ViewController.swift
//  HelloPoly
//
//  Created by student on 02/03/2016.
//  Copyright © 2016 ryandiarm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var polyModel = PolyModel()

    
    @IBOutlet var polyView: UIView!
    
    @IBAction func DecreaseSides(sender: UIButton) {
        polyModel.decrease()
        postChanges()
    }
    
    @IBAction func IncreaseSides(sender: UIButton) {
        polyModel.increase()
        postChanges()
    }
    
    private func postChanges() {
        shapeName.text = polyModel.name
        shapeSides.text = String(polyModel.numberOfSides)
        increaseButton.enabled = true
        decreaseButton.enabled = true
        if polyModel.numberOfSides == ShapeSides.Dodecagon {
            increaseButton.enabled = false
        }
        if polyModel.numberOfSides == ShapeSides.Triangle {
            decreaseButton.enabled = false
        }
        polyView.setNeedsDisplay()
        
    }
    
    @IBOutlet weak var shapeSides: UILabel!
    @IBOutlet weak var shapeName: UILabel!
    
    @IBOutlet weak var increaseButton: UIButton!
    @IBOutlet weak var decreaseButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        decreaseButton.enabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

