//
//  PolyModel.swift
//  HelloPoly
//
//  Created by student on 02/03/2016.
//  Copyright © 2016 ryandiarm. All rights reserved.
//

import Foundation

struct ShapeNames {
    static let Triangle = "Triangle"
    static let Square = "Square"
    static let Pentagon = "Pentagon"
    static let Hexagon = "Hexagon"
    static let Septagon = "Septagon"
    static let Octagon = "Octagon"
    static let Nonagon = "Nonagon"
    static let Decagon = "Decagon"
    static let Hendecagon = "Hendecagon"
    static let Dodecagon = "Dodecagon"
    
    static func getName(numSides: Int) -> String {
        switch numSides {
        case 3:
            return Triangle
        case 4:
            return Square
        case 5:
            return Pentagon
        case 6:
            return Hexagon
        case 7:
            return Septagon
        case 8:
            return Octagon
        case 9:
            return Nonagon
        case 10:
            return Decagon
        case 11:
            return Hendecagon
        case 12:
            return Dodecagon
        default:
            return ""
        }
    }
}

struct ShapeSides {
    static let Triangle = 3
    static let Square = 4
    static let Pentagon = 5
    static let Hexagon = 6
    static let Septagon = 7
    static let Octagon = 8
    static let Nonagon = 9
    static let Decagon = 10
    static let Hendecagon = 11
    static let Dodecagon = 12
}

class PolyModel: NSObject {
    var numberOfSides: Int = ShapeSides.Triangle
    var name: String = ShapeNames.Triangle
    
    func increase () {
        print(numberOfSides)
        if numberOfSides < ShapeSides.Dodecagon {
            numberOfSides += 1
            name = ShapeNames.getName(numberOfSides)
        }
    }
    
    func decrease() {
        print(numberOfSides)
        if numberOfSides > ShapeSides.Triangle {
            numberOfSides -= 1
            name = ShapeNames.getName(numberOfSides)
        }
    }
}