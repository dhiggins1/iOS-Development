//
//  PolygonView.swift
//  HelloPoly2
//
//  Created by student on 02/03/2016.
//  Copyright © 2016 ryandiarm. All rights reserved.
//

import UIKit

protocol PolygonProtocol: class {
    func pointsInRect(rect: CGRect) -> Array<CGPoint>
}

class PolygonView: UIView {
    var polygonSource: PolygonProtocol?
    
    override func drawRect(rect: CGRect) {
        var points = polygonSource?.pointsInRect(rect)
        print(points)
        UIColor.blackColor()
        
        var path = UIBezierPath()
        for point in points! {
            print(point)
            path.appendPath(UIBezierPath(arcCenter: point, radius: 2.0, startAngle: 0.0, endAngle: CGFloat(2.0 * M_PI), clockwise: true))
            path.lineWidth = 2.0
        }
        UIColor.blackColor().setFill();
        path.fill()
    }
}