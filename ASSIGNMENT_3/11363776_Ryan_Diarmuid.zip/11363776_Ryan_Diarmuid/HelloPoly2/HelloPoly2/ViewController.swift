//
//  ViewController.swift
//  HelloPoly
//
//  Created by student on 02/03/2016.
//  Copyright © 2016 ryandiarm. All rights reserved.
//

import UIKit

class ViewController: UIViewController, PolygonProtocol {
    
    var polyModel = PolyModel()
    
    
    @IBOutlet var polyView: UIView!
    
    @IBOutlet weak var polygon: PolygonView! {
        didSet {
            polygon.polygonSource = self
        }
    }
    
    @IBAction func DecreaseSides(sender: UIButton) {
        polyModel.decrease()
        postChanges()
    }
    
    @IBAction func IncreaseSides(sender: UIButton) {
        polyModel.increase()
        postChanges()
    }
    
    private func postChanges() {
        shapeSides.text = String(polyModel.numberOfSides)
        increaseButton.enabled = true
        decreaseButton.enabled = true
        if polyModel.numberOfSides == ShapeSides.Dodecagon {
            increaseButton.enabled = false
        }
        if polyModel.numberOfSides == ShapeSides.Triangle {
            decreaseButton.enabled = false
        }
        polyView.setNeedsDisplay()
        polygon.setNeedsDisplay()
    }
    
    @IBOutlet weak var shapeSides: UILabel!
    @IBOutlet weak var shapeName: UILabel!
    
    @IBOutlet weak var increaseButton: UIButton!
    @IBOutlet weak var decreaseButton: UIButton!
    
    func pointsInRect(rect: CGRect) -> Array<CGPoint> {
        print(rect)
        return polyModel.polygonPoints(rect, polyModel.numberOfSides)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        decreaseButton.enabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

